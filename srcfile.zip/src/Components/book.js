import React from 'react';
import axios from 'axios';
class Book extends React.Component {
    constructor() {
        super();
        this.state = {
            form:{
                name:"",
                author:"",
                genre:""
            },
            errors: {
                nameerr: "",
                authorerr: "",
                genre: ""
            },
            validities: {
                name: false,
                author: false,
                genre: false,
                buttonActive:false
            }
        }
    }


    validatetitle = (event) => {
        var title = event.target.value;
        var errorscopy = this.state.errors;
        var vcopy = this.state.validities;
        var formcopy = this.state.form;
        formcopy.title  = title;
        this.setState({form:formcopy});
        if(title.length===0){
            errorscopy.nameerr = "field required";
            vcopy.name = false;
        }
        else if (title.length < 4) {
            errorscopy.nameerr = "Title needs to have at least 4 characters.";
            vcopy.name = false;
        } else {
            errorscopy.nameerr = "";
            vcopy.name = true;
        }
        vcopy.buttonActive = vcopy.name && vcopy.author && vcopy.genre;
        this.setState({ errors: errorscopy, validities: vcopy });
    }

    validateauthor = (event) => {
        var author = event.target.value;
        var errorscopy = this.state.errors;
        var vcopy = this.state.validities;
        var formcopy = this.state.form;
        formcopy.author  = author;
        this.setState({form:formcopy});
        if(author.length===0){
            errorscopy.authorerr = "field required";
            vcopy.author = false;
        }
        else if (author.length < 3) {
            errorscopy.authorerr = "Author needs to have at least 3 letters.";
            vcopy.author = false
        } else {
            errorscopy.authorerr = "";
            vcopy.author = true;
        }
        vcopy.buttonActive = vcopy.name && vcopy.author && vcopy.genre;
        this.setState({ errors: errorscopy, validities: vcopy });
    }

    validategenre = (event) => {
        var genre = String(event.target.value);
        var errorscopy = this.state.errors;
        var vcopy = this.state.validities;
        var formcopy = this.state.form;
        formcopy.genre  = genre;
        this.setState({form:formcopy});
        if(genre.length===0){
            errorscopy.genreerr = "field required";
            vcopy.genre = false;
        }
        else  {
            errorscopy.genreerr = "";
            vcopy.genre = true;
        } 
        vcopy.buttonActive = vcopy.name && vcopy.author && vcopy.genre;
        this.setState({ errors: errorscopy, validities: vcopy });
    }

    resetstate = () => {
        var err = this.state.errors;
        err.nameerr = "";
        err.authorerr = "";
        err.genreerr = "";
        this.setState({ errors: err });
    }

    submitdets = (event) =>{
        event.preventDefault();
        axios.post("http://localhost:3500/books",this.state.form).then(response=>{
            this.setState({successMessage:response.data.message,errorMessage:""});
        }).catch(err=>{
            this.setState({errorMessage:(err.response?err.response.data.message:"server error"),successMessage:""})
        })
    }

    render() {
        return (

            <div className="container">
                <hr style={{ backgroundColor: "darkgoldenrod", height: "2px" }} />
                <p className="display-4 text-warning text-center">Add your Favourite Books</p><hr style={{ backgroundColor: "darkgoldenrod", height: "2px" }} />
                <div className="card form">

                    <div className="card-header bg-dark"><p className="display-4 text-warning text-center">Add A Book</p></div>
                    <div className="card-body">
                    <form onSubmit={(event)=>this.submitdets(event)}>
                        <div className="form-group">
                            <label className="h4">Title:</label>
                            <input type="text" className="text-warning form-control" placeholder="enter the title of the book" onChange={this.validatetitle} name="title" autofocus required />
                            <span className="text-danger">{this.state.errors.nameerr}</span>
                        </div>
                        <div className="form-group">
                            <label className="h4">Author:</label>
                            <input type="text" className="text-warning form-control" placeholder="enter the name of the author" onChange={this.validateauthor} name="author" required />
                            <span className="text-danger">{this.state.errors.authorerr}</span>
                        </div>
                        <div className="form-group">
                            <label className="h4">Genre:</label>
                            <select className="form-control" placeholder="enter the genre of the book" onClick={this.validategenre} name="genre" required>
                                <option value="">--Select Genre--</option>
                                <option value="Mystery thriller">Mystery thriller</option>
                                <option value="Fiction">Fiction</option>
                                <option value="Non-fiction">Non-fiction</option>
                            </select>
                            <span className="text-danger">{this.state.errors.genreerr}</span>
                        </div>
                        <div>
                            <div><button type="submit" disabled={!this.state.validities.buttonActive} className="btn btn-success" style={{ "float": "left" }}>Add A Book</button></div>
                            <div className="text-right"><button type="Reset" onClick={this.resetstate} className="btn btn-danger">Reset</button></div>
                        </div>
                        <span className="text-success">{this.state.successMessage}</span>
                        <span className="text-danger">{this.state.errorMessage}</span>
                    </form>
                    </div>
                </div>
            </div>
        )
    }
}

export default Book;