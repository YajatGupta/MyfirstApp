import React from 'react';
// import {store} from "../index"
import { connect } from 'react-redux';
class Cart extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            qty:0,
            price:0
        }
    }

    render() {
        return (
            <div className="container">
                <div className="card" style={{ backgroundColor: "black", boxShadow: "-2px -2px 30px 0px darkgoldenrod"}}>
                    <h2 className="text-warning">This is the total number of items: {this.props.qty}</h2>
                    <h2 className="text-warning">This is the total price: {this.props.price}</h2>
                </div>
            </div>
        )
    }
}
function mapStateToProps(state){
    return {
        qty:state.qty,
        price:state.price
    }
}
Cart = connect(mapStateToProps)(Cart);

export default Cart;