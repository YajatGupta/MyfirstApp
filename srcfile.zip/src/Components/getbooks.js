import React from 'react';
import Books from "./books";
import Cart from "./cart";
import axios from 'axios';
class GetBooks extends React.Component {
    constructor() {
        super();
        this.state = {
            bookdets:[]
        }
    }
    
    fetchbooks  = () =>{
        axios.get("http://localhost:3500/books").then(response=>{
            console.log(response);
            this.setState({bookdets:response.data});
        }).catch(err=>{
            this.setState({bookdets:[]});
        })
    } 

    componentDidMount(){
        this.fetchbooks();
    }

    getbooks = () => {
        return (
            <div className="row">
                <div className="col-md-8">
                    <div className="container">
                        <h2 className="text-warning text-center">Featured Books</h2>
                        <div className="row" style={{ border: "1px solid darkgoldenrod", padding: "10px" }}>{this.state.bookdets.map((book) => { return <Books bookobj={book} /> })}
                        </div>
                    </div>
                </div>
                <div className="col-md-4 fixed-bottom ml-auto"><Cart /></div>
            </div>

        )
    }

    render() {
        return (
            <div className="container"><hr style={{ backgroundColor: "darkgoldenrod" }} />{this.getbooks()}</div>
        )
    }
}
export default GetBooks;