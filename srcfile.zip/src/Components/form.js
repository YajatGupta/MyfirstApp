import React from 'react';
class Form extends React.Component {
    constructor() {
        super();
        this.state = {
            errmsgs: {
                invalidnamemsg: "",
                invalidemailmsg: "",
                invalidpassmsg: ""
            },
            checkformvalid: {
                invalidnameerr: false,
                invalidemailerr: false,
                invalidpasserr: false

            }
        }
    }
    render() {
        return (<div>
            <div>
                <div className="container">
                    <div className="card img-fluid">
                        <img src="book1.jpg" className="card-img-top" alt="card" />
                        <div className="card-body form card-img-overlay">
                            <hr style={{ "background-color": "darkgoldenrod", "height": "2px" }} />
                            <div className="form-group text-center text-warning display-4">Login</div>
                            <hr style={{ "background-color": "darkgoldenrod", "height": "2px" }} />
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="form-group"><label className="text-info h4" for="fname">FirstName:</label>
                                        <input type="text" className="form-control text-warning bg-dark" placeholder="enter your first name" name="fname" autofocus required />
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="form-group"><label className="text-info h4" for="lname">LastName:</label>
                                        <input type="text" className="form-control text-warning bg-dark" placeholder="enter your last name" name="lname" required />
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="form-group"><label className="text-info h4" for="uname">UserName:</label>
                                        <input type="text" className="form-control text-warning bg-dark" placeholder="enter your user name" name="uname" required />
                                    </div>
                                    <div className="form-group"><label className="text-info h4" for="pass">Password:</label>
                                        <input type="text" className="form-control text-warning bg-dark" placeholder="enter your password" name="pass" required />
                                    </div>

                                </div>
                                <div className="col-md-6" style={{ "border": "2px solid darkgoldenrod" }}>
                                    <div className="form-group" >
                                        <div className="h2 text-info form-group text-center" style={{ "margin-bottom": "20px" }}>Contact Details:</div>
                                        <div className="form">
                                            <form>
                                                <div className="form-group"><label className="text-info h4" for="uname">Email:</label>
                                                    <input type="text" className="form-control text-warning bg-dark" placeholder="enter your email" name="email" required />
                                                </div>
                                                <div className="form-group"><label className="text-info h4" for="uname">Mobile No:</label>
                                                    <input type="text" className="form-control text-warning bg-dark" placeholder="enter your mobile number" name="number" required />
                                                </div>
                                            </form>
                                        </div></div>
                                </div>
                            </div>
                            <div className="form-group">
                                <label className="h5" style={{ "color": "wheat" }}>Submit the details</label>
                                <button type="button" name="submit" className="btn btn-success form-control">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div style={{ "background-image": "book1.jpg" }}>

            </div>
        </div>
        )
    }
}
export default Form;