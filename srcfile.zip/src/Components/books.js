import React from 'react';
import {store} from "../index"
class Books extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            details: "",
            qty:0
        }
    }

    componentWillMount = () =>{
        var action = {
            type:"RESET"
        }
        store.dispatch(action);
    }

    renderdetails = () => {
        this.setState({ details: this.props.bookobj.desc });
    }

    hidedetails = () => {
        this.setState({ details: "" });
    }

    increase = ()  => {
        this.setState({qty:this.state.qty+1});
        var action = {
            type:"INCREMENT",
            qty:1,
            price:100
        }
        store.dispatch(action);
    }

    decrease = ()  => {
        this.setState({qty:this.state.qty-1});
        var action = {
            type:"DECREMENT",
            qty:1,
            price:100
        }
        store.dispatch(action);
    }

    render() {
        return (
            <div className="col-md-3 form-group">
                <div className="card">
                    {/* <p className=" text-warning text-center card-title text-uppercase h4" style={{ backgroundColor: "black" }}>{this.props.bookobj.title}</p> */}
                    <img src="book1.jpg" className="card-img-top" alt="book" />
                    <span className="card-title text-primary font-weight-bold text-center">{this.props.bookobj.title}</span>
                    <div className="card-text">
                        <span><span className="font-weight-bold text-dark">Author:</span> {this.props.bookobj.author}</span><br />
                        <span><span className="font-weight-bold text-dark">Genre: </span>{this.props.bookobj.genre}</span><br />
                        <span>{this.state.details}</span>
                        <div className="container">
                            <div className="row">
                                <div className="col-sm-2" >
                                    <button type="button" className="btn btn-success" style={{ marginLeft: "-15px", height: "100%" }} onClick={this.increase}>+</button>
                                </div>
                                <div className="col-sm-6">
                                    <button type="button" className="btn btn-primary" style={{ height: "50%", marginLeft: "-3px" }} onClick={this.renderdetails}>Show</button><br />
                                    <button type="button" className="btn btn-primary" style={{ height: "50%", marginLeft: "-3px", width: "155%" }} onClick={this.hidedetails}>Hide</button>
                                </div>
                                <div className="col-sm-1">
                                    <button type="button" disabled={this.state.qty===0?true:false} className="btn btn-danger" style={{ marginLeft: "-5px", height: "100%" }} onClick={this.decrease}>-</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div ></div>
        )
    }
}
export default Books;