import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import App from './App';
import Book from "./Components/book";
import Cart from "./Components/cart";
import Form from "./Components/form";
import GetBooks from "./Components/getbooks";
import * as serviceWorker from './serviceWorker';
import { BrowserRouter, Route, Redirect, Switch, Link } from 'react-router-dom';
import { createStore } from 'redux';
// import axios from 'axios';
import { Provider } from 'react-redux';

var initiaState = {
    qty: 0,
    price: 0
}
function changeState(state = initiaState, action) {
    switch (action.type) {
        case 'INCREMENT':
            var statecopy = Object.assign({}, state);
            statecopy.qty += action.qty;
            statecopy.price += action.price;
            return statecopy;
        case 'DECREMENT':
            statecopy = Object.assign({}, state);
            statecopy.qty -= action.qty;
            statecopy.price -= action.price;
            return statecopy;
        case 'RESET':
            statecopy = Object.assign({}, state);
            statecopy.qty = 0;
            statecopy.price = 0;
            return statecopy;
        default:
            return state;
    }
}

export var store = createStore(changeState);

ReactDOM.render(
    <div style={{ backgroundColor: "black" }}>
        <Provider store={store}>
            <BrowserRouter>
                <nav className="navbar navbar-expand-md ">
                    <a href="/form" className="navbar-brand text-warning h2">Book Store</a>
                    <button type="button" className="navbar-toggler text=right" data-target="#collapsible" data-toggle="collapse">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="collapsible">
                        <ul className="navbar-nav" >
                            <li className="nav-item h6"><Link to="/form" className="nav-link" style={{ color: "lightgrey" }}><u>Login</u></Link></li>
                            <li className="nav-item h6"><Link to="/addbook" className="nav-link" style={{ color: "lightgrey" }}><u>Add A Book</u></Link></li>
                            <li className="nav-item h6"><Link to="/getbooks" className="nav-link" style={{ color: "lightgrey" }}><u>View Collection</u></Link></li>
                        </ul>
                        <ul className="navbar-nav ml-auto" >
                            <li className="nav-item h6"><Link to="/cart" className="nav-link" style={{ color: "lightgrey" }}><u>Cart</u></Link></li>
                        </ul>
                    </div>
                </nav>
                <Switch>
                    <Route path="/getbooks" component={GetBooks} />
                    <Route path="/addbook" component={Book} />
                    <Route path="/form" component={Form} />
                    <Route path="/cart" component={Cart} />
                    <Route path="*" render={() => <Redirect to="/form" />} />
                </Switch>
            </BrowserRouter></Provider></div>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA

serviceWorker.unregister();
